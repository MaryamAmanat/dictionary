"use strict";
(() => {
var exports = {};
exports.id = 510;
exports.ids = [510];
exports.modules = {

/***/ 333:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ handler)
});

;// CONCATENATED MODULE: external "axios"
const external_axios_namespaceObject = require("axios");
var external_axios_default = /*#__PURE__*/__webpack_require__.n(external_axios_namespaceObject);
;// CONCATENATED MODULE: ./pages/api/info.js

async function handler(req, res) {
    if (req.method === "GET") {
        const options = {
            method: "GET",
            url: "https://dictionary-by-api-ninjas.p.rapidapi.com/v1/dictionary",
            params: {
                word: req.query.word
            },
            headers: {
                "x-rapidapi-host": "dictionary-by-api-ninjas.p.rapidapi.com",
                "x-rapidapi-key": "8529b66f39msh03267fb020891edp1a6994jsnfded95e6f109"
            }
        };
        external_axios_default().request(options).then(function(response) {
            res.status(200).json(response.data);
        }).catch(function(error) {
            console.error(error);
        });
    } else {
        res.status(400);
    }
};


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__(333));
module.exports = __webpack_exports__;

})();